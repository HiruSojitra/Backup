 #include<stdio.h>
main()
{
	int i;
	
	for(i=1;i<=5;i++)
	{
		if(i==1 || i==3||i==5)
		{
			printf("* * *\n");
		}
		else
		{
			printf("*    *\n");
		}
	}
	
  return 0;
}
