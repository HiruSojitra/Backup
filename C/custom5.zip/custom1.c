#include<stdio.h>

void main()
{
	
	int i,j;
	
	for(i=5;i>=1;i--)
	{
		for(j=1;j<=i;j++)
		{
			printf("%d",j);
		}
		printf("\n");
	}
	for(i=2;i<=5;i++)
	{
		for(j=i;j<=5;j++)
		{
			printf("%d",j);
		}
		printf("\n");
    }
}
